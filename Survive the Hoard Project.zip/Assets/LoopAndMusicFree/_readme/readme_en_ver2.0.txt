//-------------------------------------------------------------------------------------
// Loop & Music Free
// @2018 marching dream
// Version 2.0
//-------------------------------------------------------------------------------------


"Loop & Music Free" contains 34 songs of loop sound source, non-loop sound source and remix sound source of 
Ambient, Chiptune, Dance, Dreamy, Electoronic, Cinema, Pops, Rhythm, Rock genres that can be used immediately for content creation 
(15 Loops, 16 music, 3 Remixes, file format is mp3/320kbps). 

A complete version series etc... of this asset are on sale at my publisher page.
** File format of the paid version is ogg/320kbps ** 
https://assetstore.unity.com/publishers/26878 

==** File Organization **==
15 Loops
- Loop Ambient001(3:39)
- Loop Ambient008(5:02)
- Loop Chiptune001(1:52)
- Loop Dance001(2:56)
- Loop Dance004(3:04)
- Loop Dreamy005(8:41)
- Loop Electronic001(2:48)
- Loop Electronic006(1:36)
- Loop Cinema001(2:48)
- Loop Cinema002(3:48)
- Loop Pops001(2:24)
- Loop Pops005(3:12)
- Loop Rhythm003(5:38)
- Loop Rock001(3:36)
- Loop Rock006(2:30) 
16 Music
- Music Ambient003(4:28)
- Music Ambient006(8:41) 
- Music Chiptune005(2:07)
- Music Chiptune007(4:02)
- Music Dance002(1:48)
- Music Dance006(3:52)
- Music Dreamy010(5:24)
- Music Electronic001(3:37)
- Music Electronic007(3:47)
- Music Cinema001(3:21)
- Music Cinema007(5:39)
- Music Pops008(3:17)
- Music Pops017(3:30)
- Music Rhythm004(5:43)
- Music Rock001(3:07)
- Music Rock010(5:19)
3 Remixes
- Loop Pops001 Remix001(3:36)
- Loop Rock001 Remix001(3:34)
- Loop Rock001 Remix002(3:34)


Official Website
https://marchingdream.web.fc2.com/ 

Official YouTube Channel
https://www.youtube.com/user/MarchingDreamApp 

Official SoundCloud
https://soundcloud.com/marchingdream


///////////////////////////////////
1.0 
- First Release(4 Loops)
1.1
- Change Asset Name & Files Rebuilding
- Added 26 New Sound Source(13 Loops & 3 Remix ,14 Music)
1.2
- All Files Remastering & Epic genre changed to Cinema genre
1.3
- Add 4 New Sound Sources(2 Loops , 2 Music)
- All Files Remastering & Rebuilding
- Change file format from wav to mp3/320kbps
1.4
- All Files Rebuilding
- Changed the build version to 2017
2.0
- All Files Refreshing
///////////////////////////////////